#ifndef _costFunction_
#define _costFunction_

int findCost(int orderFloor,int elevFloor, int elevNextFloor,int orderButton, int elevButton);

#endif